Eternal Stew stove fuel compat

Fuel mods:
- To allow a custom fuel in the Eternal Stew stove, add `eternalstewStoveFuel: true` to the item's `attributes` in its JSON.
- The item still needs valid `combustibleProps` with a positive `burnDuration`.

- `attributes.eternalstewStoveFuel: true`
- `combustibleProps` with `burnDuration > 0`

Example using the briquettes fuel mod:
```json
	attributes: {
		eternalstewStoveFuel: true,
		displaycaseable: true,
		shelvable: true,
		onDisplayTransform: {
			origin: { x: 0.5, y: 0, z: 0.5 },
			scale: 0.8
		},
		onTongTransform: {
			translation: { x: -0.77, y: -0.74, z: -0.665 },
			rotation: { x: 96, y: 19, z: 96 },
			scale: 0.79
		},
		shatteredStack: { type: "block", code: "clayshattered-singlecenter" },
	},
```
