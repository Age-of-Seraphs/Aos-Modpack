#version 330 core
uniform sampler2D primaryScene;
uniform sampler2D depthTex;
uniform float exposureLag;
uniform float exposureMult;
in vec2 texCoord;
out vec4 outColor;

void main()
{
    vec4 color = texture(primaryScene, texCoord);
    vec3 originalColor = color.rgb;
    outColor.a = color.a;

    float depth = texture(depthTex, texCoord).r;
    float isSky = step(0.9999, depth);

    float finalBrightness = max(max(originalColor.r, originalColor.g), originalColor.b);
    float maskEmission = smoothstep(0.4, 1.0, finalBrightness * 2.0);
    float lightMask = clamp(maskEmission, 0.0, 1.0);

    float blowout = pow(exposureLag, 0.5) * (0.5 + 0.5 * smoothstep(0.0, 4.0, exposureLag)) * smoothstep(0.0, 0.25, exposureLag);

    vec3 outRgb = originalColor;

    float lightBoost = lightMask * blowout;
    vec3 boost1 = originalColor * lightBoost;

    float warmth = (originalColor.r + originalColor.g * 0.5) / max(0.01, originalColor.b + 0.5);
    float warmMask = smoothstep(0.4, 3.0, warmth) * lightMask * blowout;
    vec3 boost2 = vec3(warmMask * 0.7, warmMask * 0.5, 0.0);

    float blowoutIntensity = blowout * lightMask * finalBrightness;
    vec3 boost3 = originalColor * blowoutIntensity * 0.6;

    vec3 totalBoost = (boost1 + boost2 + boost3) * exposureMult;
    totalBoost *= (1.0 - isSky * 0.5);

    outRgb += totalBoost;

    outColor.rgb = outRgb;
}
